const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const path = require("path");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname, "public")));

let users = {};

io.on("connection", (socket) => {
  console.log("User connected:", socket.id);

  socket.on("join", (username) => {
    users[socket.id] = username;
    console.log(username + " joined");
    io.emit("message", { user: "System", text: username + " joined the chat" });
  });

  socket.on("sendMessage", (msg) => {
    if (users[socket.id]) {
      io.emit("message", { user: users[socket.id], text: msg });
    }
  });

  socket.on("disconnect", () => {
    const username = users[socket.id];
    delete users[socket.id];
    if (username) {
      console.log(username + " disconnected");
      io.emit("message", { user: "System", text: username + " left the chat" });
    }
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log("Server running on port " + PORT);
});
